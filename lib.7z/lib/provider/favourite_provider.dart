import 'package:flutter/material.dart';
import 'package:footwear/model/products_model.dart';

class FavouriteProvider extends ChangeNotifier {
  final List<ProductModel> _modelList = [];
  List<ProductModel> get modelList => _modelList;

  void toggleFavourite(String titile){
  }
}
